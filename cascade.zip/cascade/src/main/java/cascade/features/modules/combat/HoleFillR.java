package cascade.features.modules.combat;

import cascade.features.modules.Module;
import cascade.features.setting.Setting;
import cascade.util.misc.Timer;
import cascade.util.player.HoleUtil;
import net.minecraft.entity.Entity;

import java.awt.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class HoleFillR extends Module {

    public HoleFillR() {
        super("HoleFillR", Category.COMBAT, "");
    }

    /*Setting<Double> range = new ValueBuilder().withDescriptor("Range").withValue(5.0).withRange(1.0, 10.0).register(this);
    Setting<Double> wallRange = new ValueBuilder().withDescriptor("Wall Range").withValue(3.0).withRange(1.0, 10.0).register(this);
    Setting<Integer> delay = new ValueBuilder().withDescriptor("Delay", "delay").withValue(1).withRange(0, 1000).register(this);
    Setting<Integer> blocksPerTick = new ValueBuilder().withDescriptor("Blocks Per Tick", "blocksPerTick").withValue(1).withRange(1, 10).register(this);
    Setting<Boolean> disableAfter = new ValueBuilder().withDescriptor("Disable", "disable").withValue(true).register(this);
    Setting<Boolean> doubles = new ValueBuilder().withDescriptor("Doubles").withValue(true).register(this);
    Setting<Boolean> noSelfFill = new ValueBuilder().withDescriptor("No Self Fill").withValue(false).register(this);
    Setting<Double> selfDist = new ValueBuilder().withDescriptor("Self Dist").withValue(1).withRange(0, 3).register(this);
    Timer timeSystem = new Timer();
    List<HoleUtil.Hole> holes = new ArrayList<HoleUtil.Hole>();
    Map<HoleUtil.Hole, Long> renderPositions = new HashMap<HoleUtil.Hole, Long>();
    Entity target;
    long currentTime;*/
}