package cascade.event.events;

import cascade.event.EventStage;
import net.minecraftforge.fml.common.eventhandler.Cancelable;

@Cancelable
public class CrystalTextureEvent extends EventStage {

}